/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.ArrayList;
import model.Product;

public class ProductService {

    private ArrayList<Product> products = new ArrayList<>();    //list sa tanan product na e store

    public void addProduct(Product product) {   //para maka add me og item
        products.add(product);  //kani kay e sulog ang product sa listahan
    }
    public ArrayList<Product> getProducts() {   //simpol, para makuha tanan prodct
        return products;    //balika ng list
    }
    public void updateProduct(int id, String name, double price, int quantity) {
        for (Product product : products) {  //check tanan prdct indibidwally
            if (product.getId() == id) {    //chek if same ba id
            product.setName(name);          //change name
            product.setPrice(price);
            product.setQuantity(quantity);
            }
        }
    }
    public void deleteProduct(int id) {     //delet ang prdct using id
        products.removeIf(p -> p.getId() == id);    //automatic na tanggalon if same og id
    }
}
