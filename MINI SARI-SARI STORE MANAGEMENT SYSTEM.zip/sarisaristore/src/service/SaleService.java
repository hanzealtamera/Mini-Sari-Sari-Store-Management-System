/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.ArrayList;
import model.Sale;
import model.Product; 

public class SaleService {
    private ArrayList<Sale> sales = new ArrayList<>();  //store sales bb
    public String addSale(Product product, int qty) {   //pra ma accses an sale

    product.setQuantity(product.getQuantity() - qty);   //reduce stock f ma kwan 2-1

    double total = product.getPrice() * qty;    //compute ang bayron

    sales.add(new Sale(product.getName(), qty, total)); //store bago na list like e save btaw
    
    product.setQuantity(product.getQuantity() - qty);
    sales.add(new Sale(product.getName(), qty, total));
    return "Sale successful!";

 
    
  

    }
}    