/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.ArrayList;
import model.Utang;

public class UtangService {

    private ArrayList<Utang> utangList = new ArrayList<>();

    // ADD
    public void addUtang(Utang utang) {
        utangList.add(utang);
    }

    // GET
    public ArrayList<Utang> getUtang() {
        return utangList;
    }

    // UPDATE
    public boolean updateUtang(int id, String field, String newValue) {

        for (Utang utang : utangList) {

            if (utang.getId() == id) {

                switch (field) {

                    case "Customer Name":
                        utang.setCustomerName(newValue);
                        break;

                    case "Contact No.":
                        utang.setCustomerNumber(newValue);
                        break;

                    case "Item":
                        utang.setProductName(newValue);
                        break;

                    case "Amount":
                        try {
                            utang.setAmount(Double.parseDouble(newValue));
                        } catch (NumberFormatException e) {
                            return false;
                        }
                        break;

                    case "Date":
                        utang.setDate(newValue);
                        break;

                    case "Due Date":
                        utang.setDueDate(newValue);
                        break;

                    case "Status":
                        utang.setStatus(newValue);
                        break;

                    default:
                        return false;
                }

                return true;
            }
        }

        return false;
    }

    // DELETE
    public boolean deleteUtang(int id) {

        return utangList.removeIf(
            utangs -> utangs.getId() == id
        );
    }
}