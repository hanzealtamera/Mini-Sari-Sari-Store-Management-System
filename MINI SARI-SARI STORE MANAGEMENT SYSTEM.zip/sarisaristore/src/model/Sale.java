/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
public class Sale {

    private int id;         //
    private String productName;
    private int quantity;
    private double total;

    public Sale(String productName, int quantity, double total) {   //constructor
    this.productName = productName;         //ez para ma change ang value
    this.quantity = quantity;               //para makahimo new infos
    this.total = total;                     //new values na e add
    }
    public int getId() {        //kwaon id
        return id; 
    }
    public void setId() {       //change id
        this.id = id;           //e add new value
    }
    public String getProductName() { 
        return productName; 
    }
    public void setProductName(String productName) {
        this.productName = productName; 
    }
    public int getQuantity() {
        return quantity; 
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity; 
    }
    public double getTotal() { 
        return total; 
    }
    public void setTotal(double total) {
        this.total = total; 
    }
}


