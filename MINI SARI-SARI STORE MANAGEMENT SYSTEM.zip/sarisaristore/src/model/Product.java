/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Lenovo
 */
public class Product {

    private int id;         //gng mga varibles na mag store og
    private String name;    //informations
    private double price;
    private int quantity;

    public Product(int id, String name, double price, int quantity) {   //constructor
        this.id = id;       //gng para makahimo og new na infos
        this.name = name;   //this. kay ang new na value na imo e add
        this.price = price;
        this.quantity = quantity;
    }

    public int getId() {    //kuhaon id
        return id;          //balik!
    }
    public String getName() { //kwaon name
        return name; 
    }
    public void setName(String name) {  //e change ang name
        this.name = name;               //this. kay new value na imong e put
    }
    public double getPrice() { 
        return price; 
    }
    public void setPrice(double price) {
        this.price = price; 
    }
    public int getQuantity() {
        return quantity; 
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity; 
    }
}

