/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sarisaristore;
import gui.Welcome;

public class Main {

    public static void main(String[] args) {    //PARA MA RUN UNA ANG WELCOME
        java.awt.EventQueue.invokeLater(() -> {
            new Welcome().setVisible(true);
        });
    }
}